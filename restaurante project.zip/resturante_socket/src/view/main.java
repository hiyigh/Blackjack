package view;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import controller.Manager;
import model.Dtos.China;
import model.Dtos.Cook;
import model.Dtos.France;
import model.Dtos.Italia;
import model.Dtos.Japan;
import model.Dtos.Korea;
import model.Dtos.Order;
import model.Dtos.Spain;
import model.Entity.Customer;
import model.Entity.Reservation;
import model.Entity.Review;
import model.Interfaces.Info;

public class main {
	public static Scanner sc = new Scanner(System.in);
	public static ArrayList<Cook> menu = new ArrayList<>();
//	public static ArrayList<Socket> customerSocketList = new ArrayList<Socket>();
	public static ArrayList<ClientSocketThread> list = new ArrayList<>();
	private static final int customerId = (int) (Math.random() * 100000);

	public static void main(String[] args) {
		ServerSocket ss;
		try {
			ss = new ServerSocket(8282);
			Socket cs = null;
			boolean flag = false;
			int cnt = 0;
			while (!flag) {
				cs = ss.accept();
				synchronized (list) {
                    ClientSocketThread cst = new ClientSocketThread(cs, cnt++);
                    list.add(cst);

                    if (cnt > 25) {
                        PrintWriter pw = new PrintWriter(cs.getOutputStream());
                        list.remove(cst);
                        cst.close();
                        --cnt;
                    } else {
                        cst.start();
                    }
                }
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static class ClientSocketThread extends Thread {
		private Socket cs;
		private BufferedReader br;
		private PrintWriter pw;
		private int cNum;
		boolean isActive;

		public ClientSocketThread(Socket cs, int cNum) throws IOException {
			super();
			this.cs = cs;
			this.cNum = cNum;
			this.br = new BufferedReader(new InputStreamReader(cs.getInputStream()));
			this.pw = new PrintWriter(cs.getOutputStream());
			this.isActive = true;
		}

		public void close() {
			try {
				mPrintln(pw, "만석");
				System.out.println("만석: " + cNum);
				cs.close();
			} catch (IOException e) {
			}
		}

		@Override
		public void run() {

			Chef chef = Chef.callChef();
			Manager manager = Manager.callManager();
			Customer customer = null;
			System.out.println("cNum 입장: " + cNum);
			char yn;
			boolean exist = false;
			boolean newCustomer = false;
			// 등록
			try {
				while (isActive) {
					mPrintln(pw, "Hello world Resturante");
					chef.setBrAndPw(br, pw);

					mPrintln(pw, "신규, 기존 고객 -> y or 미등록 -> n");

					callInput(pw);
					int cyn = inputCh(pw, br);
					if (cyn == 1) {
						mPrintln(pw, "고객명(영어만 입력가능) : ");
						callInput(pw);

						String name = inputStr(pw, br);
						
//						if (name.equals("null")) {
//							mPrintln(pw,"not null");
//							continue;
//						}

						if(name != null) {					
							mPrintln(pw, "전화번호 '-' 없이 숫자만 입력: ");
							callInput(pw);
							
							int phone = inputInt(pw, br);
							
							customer = new Customer(name, phone);
							customer.setCustomerNum(customerId);
							
							if (!checkCustomerList(customer, manager)) {
								exist = true;
								mPrintln(pw, "기존 고객");
								ArrayList<Info> cList = manager.getCustomerInfoList();
								Customer c = null;
								for (int i = cList.size() - 1; i >= 0; --i) {
									c = (Customer) cList.get(i);
									if (c.equals(customer)) {
										customer.setName(name);
										customer.setPhone(phone);
										customer.setCustomerNum(c.getCustomerNum());
										customer.orderList = new ArrayList<Order>();
										customer.review = null;
										
										manager.deleteCustomerInfo(c.getCustomerNum(), name);
									}
								}
							} else {
								newCustomer = true;
								mPrintln(pw, "신규 고객");
							}
						}
					} 
					if (cyn == 0) {
						customer = new Customer();
						customer.setCustomerNum(customerId);
					} else {
						mPrintln(pw, "잘못된 요청");
					}
					mPrintln(pw, "주문 시작");

					setMenu();
					// 주문
					while (true) {
						mPrintln(pw, "국가 선택");
						mPrintln(pw, "1.korea 2.japan 3.china 4.spain 5.france 6.italia");

						callInput(pw);
						int nation = inputInt(pw, br);
						nation = checkNumBoundary(nation, 1, 6, pw, br);

						Order orderPaper = new Order();
						orderPaper.setNationNum(nation);

						mPrintln(pw, "menu 선택");
						showMenu(nation, pw);

						int menu = inputInt(pw, br);
						menu = checkNumBoundary(menu, 1, 2, pw, br);

						orderPaper.setMenuNum(menu);
						orderPaper.setPrice();
						orderPaper.customerNum = customer.getCustomerNum();

						customer.orderList.add(orderPaper);
						mPrintln(pw, "추가 주문? y or n");
						callInput(pw);

						cyn = inputCh(pw, br);
						if (cyn == -1) {
							mPrintln(pw, "추가 주문 오류 다음으로");

							chef.setOrderList(manager.sendOrder(customer, customer.getCustomerNum()));
							break;
						} else if (cyn == 0) {
							chef.setOrderList(manager.sendOrder(customer, customer.getCustomerNum()));
							break;
						}
					}
					mPrintln(pw, "");
					// review, reservation
					mPrintln(pw, "리뷰 작성 여부 y or n");
					callInput(pw);

					cyn = inputCh(pw, br);
					if (cyn == 1) {
						writeReview(customer, pw, br);
					} else if (cyn == -1) {
						mPrintln(pw, "잘못된 입력 넘어갑니다");
					}
					
					if (customer.getPhone() != -1) {						
						manager.addFileInfo(customer);
					}

					if (customer.getPhone() != -1) {
						if (customer.review.getScore() >= 3) {
							mPrintln(pw, "다음 식사 예약 여부 y or n");
							callInput(pw);
							cyn = inputCh(pw, br);
							if (cyn == 1) {
								boolean alreadyReserved = manager.alreadyReserved(customer);
								boolean newReservation = false;
								if (alreadyReserved) {
									mPrintln(pw, "이미 예약된 고객입니다.");
									newReservation = cancelReservation(manager);
								}

								if (!alreadyReserved || newReservation) {
									mPrintln(pw, "예약 가능");
									Reservation r = makeReservation(customer, pw, br);
									manager.addFileInfo(r);
									if (r == null) {
										mPrintln(pw, "예약 취소");
									} else {
										mPrintln(pw, "예약 완료");
									}
								}
							} else if (cyn == -1) {
								mPrintln(pw, "잘못된 입력 넘어갑니다");
							}
						}
					}
					// 계산
					System.out.println("bill: " + customer.getCustomerNum() + " " + customer.getName());
					int bill = manager.paying(customer.getCustomerNum());
					pw.println("잠시만 기다려주세요");
					pw.flush();

					mPrintln(pw, "");

					pw.print("계산중");
					for (int i = 0; i < 10; ++i) {
						pw.print(".");
						pw.flush();
						try {
							Thread.sleep(200);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					mPrintln(pw, "");

					mPrintln(pw, "계산 : " + bill);
					mPrintln(pw, "안녕히 가세요");

					mPrintln(pw, "");
					mPrintln(pw, "직원?");
					callInput(pw);

					String password = inputStr(pw, br);
					if (password.equals("itsme")) {
						while (true) {
							mPrintln(pw, "고객정보 및 예약정보 확인? y or n");
							callInput(pw);

							cyn = inputCh(pw, br);
							if (cyn == 1) {
								getInfo(manager, pw, br);
								int num;
								while (true) {
									mPrintln(pw, "고객 정보 삭제 = 1, 예약 삭제 = 2, 그만 = 3");
									callInput(pw);
									num = inputInt(pw, br);
									num = checkNumBoundary(num, 1, 3, pw, br);
									if (num == 1) {
										mPrintln(pw, "삭제할 고객 번호 입력 : ");
										callInput(pw);
										int input = inputInt(pw, br);
										
										mPrintln(pw, "삭제할 고객 이름 입력: ");
										callInput(pw);
										String cName = inputStr(pw, br);
										
										manager.deleteCustomerInfo(input, cName);
									} else if (num == 2) {
										mPrintln(pw, "삭제할 예약자명 입력: ");
										callInput(pw);

										String name = inputStr(pw, br);

										mPrintln(pw, "예약자 전화번호 입력: ");
										callInput(pw);
										int cNum = inputInt(pw, br);
										manager.deleteReservationInfo(name, customer.getPhone());
									} else if (num == 3) {
										break;
									}
								}
							} else if (cyn == 0) {
								break;
							}
						}
						mPrintln(pw, "퇴근");
						isActive = false;
					} else {
						mPrintln(pw, "관계자 외 출입금지");
						isActive = false;
					}
				}
			} catch (SocketException e) {
				e.printStackTrace();
				System.out.println("종료");
			} catch (IOException e) {
				System.out.println("IOException");
				e.printStackTrace();
			} finally {
				try {
					cs.close();
					br.close();
					pw.close();
					list.remove(cs);
				} catch (Exception e) {
					System.out.println("close exception");
					e.printStackTrace();
				}
			}
		}

		private boolean cancelReservation(Manager manager) throws IOException {
			mPrintln(pw, "기존 예약 취소? y or n");
			callInput(pw);
			String name = null;
			int phone;
			int cyn = inputCh(pw, br);
			if (cyn == 1) {
				mPrintln(pw, "이름 입력");
				callInput(pw);
				name = inputStr(pw, br);
				mPrintln(pw, "전화번호 입력");
				callInput(pw);
				phone = inputInt(pw, br);
				if (!manager.deleteReservationInfo(name, phone)) {
					mPrintln(pw, "예약자가 아닙니다.");
					return false;
				} else {
					mPrintln(pw, "예약 삭제 완료");
					return true;
				}
			}
			return false;
		}
	}

	private static int checkYesOrNo(char yn, PrintWriter pw) {
		try {
			if (yn == 'y' || yn == 'Y') {
				System.out.println("yes or no : y");
				return 1;
			} else if (yn == 'n' || yn == 'N') {
				System.out.println("yes or no : n");
				return 0;
			} else {
				mPrintln(pw, "잘못된 입력");
				mPrintln(pw, "y or n 입력");
				return -1;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
	}

	private static int inputCh(PrintWriter pw, BufferedReader br) throws IOException {
		char ch;
		int cyn;
		while (true) {
			ch = br.readLine().trim().charAt(0);
			cyn = checkYesOrNo(ch, pw);
			if (cyn != -1) {
				return cyn;
			} else {
				callInput(pw);
			}
		}
	}

	private static int inputInt(PrintWriter pw, BufferedReader br) {
		int i;
		while (true) {
			try {
				i = Integer.parseInt(br.readLine().trim());
				if(i <= 0) {
					throw new NumberFormatException();
				}
				break;
			} catch (NumberFormatException | IOException e) {
				mPrintln(pw, "잘못된 입력");
				mPrintln(pw, "양수만 입력");
				callInput(pw);
			}
		}
		return i;
	}

	private static int checkNumBoundary(int ck, int start, int end, PrintWriter pw, BufferedReader br) {
		int i = ck;

		while (true) {
			if (start <= i && i <= end) {
				System.out.println("입력한 숫자 : " + i);
				return i;
			} else {
				mPrintln(pw, "잘못된 입력");
				mPrintln(pw, "범위 밖 입력");
				callInput(pw);
			}
			i = inputInt(pw, br);
		}
	}

	private static String inputStr(PrintWriter pw, BufferedReader br) {
		String str = null;
		boolean flag = false;
		while (!flag) {
			try {
				str = br.readLine();
				Pattern pattern = Pattern.compile("^[a-zA-Z]*$");
				Matcher matcher = pattern.matcher(str);
				if (!matcher.matches()) {
					mPrintln(pw, "잘못된 입력");
					mPrintln(pw, "영어만 입력");
					callInput(pw);
				} else {
					flag = true;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		System.out.println("입력한 문자 : " + str);
		return str;
	}

	private static void getInfo(Manager manager, PrintWriter pw, BufferedReader br) {
		ArrayList<Info> customerInfo = manager.getCustomerInfoList();
		ArrayList<Info> reservationInfo = manager.getReservationInfoList();
		Customer c = null;
		Reservation re = null;
		int sc;

		for (Info in : customerInfo) {
			c = (Customer) in;
			pw.print(c.toString());
			if (c.review != null) {
				sc = c.review.score;
				mPrintln(pw, " 리뷰: " + sc);
			} else {
				pw.println();
				pw.flush();
			}
		}

		for (Info in : reservationInfo) {
			re = (Reservation) in;
			mPrintln(pw, re.getReservationInfo());
		}
	}

	private static boolean checkCustomerList(Customer customer, Manager manager) {
		ArrayList<Info> customerList = manager.getCustomerInfoList();
		try {
			if (!customerList.isEmpty()) {
				for (Info in : customerList) {
					Customer c = (Customer) in;
					if (c.equals(customer)) {
						return false;
					}
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return true;
	}

	private static Reservation makeReservation(Customer customer, PrintWriter pw, BufferedReader br) {
		Reservation reservation = new Reservation();
		String dateStr = null;
		int people = 0;
		boolean flag = true;

		reservation.setCustomerName(customer.getName());
		loop: while (flag) {
			mPrintln(pw, "날짜를 입력하세요 (yyyy-MM-dd): ");
			callInput(pw);

			while (true) {
				try {
					dateStr = br.readLine();
					Pattern pattern = Pattern.compile("\\d{4}-\\d{2}-\\d{2}");
					Matcher matcher = pattern.matcher(dateStr);
					if (!matcher.matches()) {
						mPrintln(pw, "잘못된 입력");
						mPrintln(pw, "잘못된 형식의 날짜입니다. 예약을 취소하시겠습니까? y or n");
						callInput(pw);

						int checkReservation = inputCh(pw, br);
						if (checkReservation == 0) {
							continue loop;
						} else if (checkReservation == 1) {
							flag = false;
							break;
						}
					} else {
						int error = -1;
						String[] str = dateStr.split("-");
						int year = 0;
						int month = 0;
						int day = 0;

						for (int i = 0; i < str.length; ++i) {
							switch (i) {
							case 0:
								int currentYear = LocalDate.now().getYear();
								year = Integer.parseInt(str[i]);
								if (currentYear > year) {
									error = 0;
								}
								break;
							case 1:
								int currentMonth = LocalDate.now().getMonthValue();
								month = Integer.parseInt(str[i]);
								if (!(currentMonth < month && month < 13)) {
									error = 1;
								}
								break;
							case 2:
								int currentDay = LocalDate.now().getDayOfMonth();
								day = Integer.parseInt(str[i]);
								if (month == 2) {
									if (!(0 < day && day < 29)) {
										error = 2;
									}
								} else if (month % 2 == 0) {
									if (!(0 < day && day < 30)) {
										error = 2;
									}
								} else {
									if (!(0 < day && day < 31)) {
										error = 2;
									}
								}
								break;
							}
						}

						if (error != -1) {
							mPrintln(pw, "잘못된 입력");
							mPrintln(pw, "예약할 수 없는 날짜입니다.(다음달 부터 예약 가능) 예약을 취소하시겠습니까? y or n");
							callInput(pw);

							int checkReservation = inputCh(pw, br);
							if (checkReservation == 0) {
								continue loop;
							} else if (checkReservation == 1) {
								flag = false;
								break;
							}
						}

						mPrintln(pw, "입력한 날짜: " + dateStr);
						flag = true;
						break;
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			if (flag) {
				reservation.setDate(dateStr);
				break;
			}
		}
		if (flag) {
			mPrintln(pw, "인원수 입력: ");
			callInput(pw);

			people = inputInt(pw, br);
			people = checkNumBoundary(people, 1, 10, pw, br);

			reservation.setNumPeople(people);
			reservation.setTableNum((int) (Math.random() * (20) + 1));
			reservation.setPhone(customer.getPhone());
			return reservation;
		} else {
			return null;
		}
	}

	private static void writeReview(Customer customer, PrintWriter pw, BufferedReader br) {
		Review review = new Review();
		review.setCustomerNum(customerId);
		review.setWriter(customer.getName());

		mPrintln(pw, "리뷰 점수 1 ~ 5 점");
		callInput(pw);

		int score = inputInt(pw, br);
		if (checkNumBoundary(score, 1, 5, pw, br) != -1) {
			review.setScore(score);
		}
		customer.review = review;
	}

	private static void showMenu(int nation, PrintWriter pw) {
		mPrintln(pw, menu.get(nation - 1).toString());
		callInput(pw);
	}

	private static void setMenu() {
		menu.add(new Korea());
		menu.add(new Japan());
		menu.add(new China());
		menu.add(new Spain());
		menu.add(new France());
		menu.add(new Italia());
	}

	private static void mPrintln(PrintWriter pw, String str) {
		pw.println(str);
		pw.flush();
	}

	private static void callInput(PrintWriter pw) {
		pw.println("	");
		pw.flush();
	}
}