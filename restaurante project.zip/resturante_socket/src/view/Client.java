package view;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
	private static final Scanner sc = new Scanner(System.in);
	private static int serverPort = 8282;
	private static BufferedReader br = null;
	private static PrintWriter pw = null;

	public static void main(String[] args) {
			try {
				Client client = new Client();
			} catch (UnknownHostException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
	}

	public Client() throws UnknownHostException, IOException {	
			Socket ss = new Socket("192.168.20.133", serverPort);
			br = new BufferedReader(new InputStreamReader(ss.getInputStream()));
			pw = new PrintWriter(ss.getOutputStream());
			
			Thread th = new Thread(new Runnable() {	
				@Override
				public void run() {
					boolean flag = false;
					String serverMessage = null;
						try {
							while (!flag) {
									serverMessage = br.readLine(); 
								if (!serverMessage.equals("	") && !serverMessage.equals("잘못된 입력") && !serverMessage.equals("퇴근") && !serverMessage.equals("관계자 외 출입금지")) {	
									System.out.println(serverMessage);
								}
								
								if (serverMessage.equals("퇴근") || serverMessage.equals("관계자 외 출입금지")) {
									System.out.println(serverMessage);
									flag = true;
									break;
								}
								if (serverMessage.equals("잘못된 입력")) {
									System.out.println(serverMessage);
									System.out.println(br.readLine().trim()); // 원인 출력
								} 
								if (serverMessage.equals("	")) {
									String msg = sc.nextLine();
									while (msg.isEmpty()) {
										msg = sc.nextLine().trim();
									}
									pw.println(msg);
									pw.flush();
								} 
							}
						} catch (IOException e) {
							System.out.println("서버 종료");
							flag = true;
						} finally {
							try {
								br.close();
								pw.close();
							} catch (IOException e) {
								e.printStackTrace();
							}						
						}
					}
			});
			th.start();
	}
}
