package view;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.util.ArrayList;

import model.Dtos.China;
import model.Dtos.Cook;
import model.Dtos.France;
import model.Dtos.Italia;
import model.Dtos.Japan;
import model.Dtos.Korea;
import model.Dtos.Order;
import model.Dtos.Spain;

public class Chef<T> {
	private static final Chef chef = null;
	private ArrayList<Order> orderList;
	private ArrayList<T> foodList = new ArrayList<>();
	private BufferedReader br;
	private PrintWriter pw;
	private Chef() {}
	public static Chef callChef() {
		if(chef == null) {
			return new Chef();
		}
		return chef;
	}
	public void setOrderList(ArrayList<Order> orderList) {
		this.orderList = orderList;
		setFoodList();
	}
	public void setBrAndPw(BufferedReader br, PrintWriter pw) {
		this.br = br;
		this.pw = pw;
	}

	public void setFoodList() {		
		for(Order o : orderList) {			
			switch(o.getNationNum()){
			case 1:
				Cook korea = new Korea();
				korea.setMenu(o.getMenuNum());
				foodList.add((T) korea);
				break;
			case 2:
				Cook japan = new Japan();
				japan.setMenu(o.getMenuNum());
				foodList.add((T) japan);
				break;
			case 3:
				Cook china = new China();
				china.setMenu(o.getMenuNum());
				foodList.add((T) china);
				break;
			case 4:
				Cook spain = new Spain();
				spain.setMenu(o.getMenuNum());
				foodList.add((T) spain);
				break;
			case 5:
				Cook france = new France();
				france.setMenu(o.getMenuNum());
				foodList.add((T) france);
				break;
			case 6:
				Cook italia = new Italia();
				italia.setMenu(o.getMenuNum());
				foodList.add((T) italia);
				break;
			}
		}						
		getFoodList();
	}
	private void getFoodList() {
		// TODO Auto-generated method stub
		int cn = orderList.get(0).customerNum;		
		String menuName = null;
		
		for(T cook : foodList) {		
			if(cook instanceof Korea) {
				Korea k = (Korea)cook;
				menuName = k.getMenu();
			} else if (cook instanceof Japan) {
				Japan j = (Japan)cook;
				menuName =  j.getMenu();
			} else if (cook instanceof China) {				
				China c = (China)cook;
				menuName = c.getMenu();
			} else if (cook instanceof Spain) {
				Spain s = (Spain)cook;
				menuName =  s.getMenu();
			} else if (cook instanceof France) {
				France f = (France)cook;
				menuName =  f.getMenu();
			} else if (cook instanceof Italia) {
				Italia i = (Italia)cook;
				menuName =  i.getMenu();
			}
			pw.println("잠시만 기다려주세요");
			pw.flush();
			pw.println();
			pw.flush();
			
			Cook co = (Cook) cook;
			co.ready(br, pw);
			timer(3);
			
			pw.println();
			pw.flush();
			
			joryyory("조리중");
			
			StringBuilder sb = new StringBuilder();
			sb.append(co.cooking());
			pw.println(sb.toString());
			pw.flush();
	
			joryyory("요리중");		
			
			pw.println(cn + "번 손님 " + menuName);
			pw.flush();		
		}
	}
	private void joryyory(String joryyory) {
		pw.print(joryyory);
		pw.flush();
		for(int i = 0; i < 10; ++i) {
			pw.print(".");
			pw.flush();
			timer(2);
		}
		pw.println();
		pw.flush();	
	}
	private void timer(int num) {
		int time = num * 100;
		try {
			Thread.sleep(time);
		}catch(InterruptedException e) {			
		}
	}
}
