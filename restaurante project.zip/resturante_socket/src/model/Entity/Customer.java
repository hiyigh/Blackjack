package model.Entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;

import model.Dtos.Order;
import model.Interfaces.Info;

public class Customer implements Info, Serializable{
	private int customerNum;
	private String name;
	private int phone;
	public ArrayList<Order> orderList = new ArrayList<>();
	public Review review = null;
	
	public Customer() {
		this.name = null;
		this.phone = -1;
	}
	public Customer(String name, int phone) {
		this.name = name;
		this.phone = phone;
	}
	public int getCustomerNum() {
		return customerNum;
	}
	public void setCustomerNum(int customerNum) {
		this.customerNum = customerNum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public void setReview(Review review) {
		this.review = review;
	}
	@Override
	public int hashCode() {
		int result = 17;
		result = result * phone;
	    return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (!(obj instanceof Customer)) {
			return false;
		}
		Customer c = (Customer)obj;
		System.out.println("this name" + this.name);
		return (this.name.equals(c.name) && this.phone == c.phone); 
	}
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		 sb.append("고객 번호: ").append(this.customerNum)
	      .append(", 이름: ").append(this.name)
	      .append(", 전화번호: ").append(this.phone);
		 
		return sb.toString(); 
	}
}
