package model.Entity;

import java.io.Serializable;
import java.util.Date;

import model.Interfaces.Info;

public class Reservation implements Info, Serializable{
	private String date;
	private String customerName;
	private int phone;
	private int numPeople;
	private int tableNum;
	
	public String getReservationInfo() {
	    StringBuilder info = new StringBuilder();
	    info.append("날짜 : ").append(date);
	    info.append(", 예약자 : ").append(customerName);
	    info.append(", 전화번호: ").append(phone);
	    info.append(", 인원 : ").append(numPeople);
	    info.append(", 테이블 : ").append(tableNum);
	    return info.toString();
	}
	public String getCustomerName() {
		return this.customerName;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public void setNumPeople(int numPeople) {
		this.numPeople = numPeople;
	}
	public int getNumPeople() {
		return this.numPeople;
	}
	public int getTableNum() {		
	}
	public void setTableNum(int tableNum) {
		this.tableNum = tableNum;
	}

	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	
}
