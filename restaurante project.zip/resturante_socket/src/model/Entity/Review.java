package model.Entity;

import java.io.Serializable;

import model.Interfaces.Info;

public class Review implements Info, Serializable{
	private String writer;
	private int customerNum;
	public int score;
	public Review() {
		this.writer = null;
		this.customerNum = -1;
		this.score = 0;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public int getCustomerNum() {
		return this.customerNum;
	}
	public void setCustomerNum(int cn) {
		this.customerNum = cn;
	}
}
