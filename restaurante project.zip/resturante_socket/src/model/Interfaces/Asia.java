package model.Interfaces;

public interface Asia {
	public static final String fortunecookie = "fortuneCookie";
	String boiling();
	String mixing();
	String getFortuneCookie();
}
