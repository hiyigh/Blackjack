package model.Interfaces;

public interface Western {
	public static final String bread = "bread";
	String deepFrying();
	String Grilling();
	String Sauteing();
	String getBread();
}
