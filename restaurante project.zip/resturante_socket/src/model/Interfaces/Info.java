package model.Interfaces;

public interface Info{
}
