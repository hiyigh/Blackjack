package model.Dtos;

public class Table {
	public int tableNum;
}
