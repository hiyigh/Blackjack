package model.Dtos;

import java.io.Serializable;

public class Order implements Serializable{
	public int orderNum;
	public int customerNum;
	
	private int nationNum;
	private int menuNum;
	
	private int price;

	public int getNationNum() {
		return nationNum;
	}
	public int getMenuNum() {
		return menuNum;
	}
	
	public void setNationNum(int nationNum) {
		this.nationNum = nationNum;
	}
	public void setMenuNum(int menuNum) {
		this.menuNum = menuNum;
		setPrice();
	}

	public int getPrice() {
		return price;
	}
	public void setPrice() {
		switch(nationNum) {
		case 1:
			Korea k = new Korea();
			k.setMenu(menuNum);
			this.price = k.getPrice();
			break;
		case 2:
			Japan j = new Japan();
			j.setMenu(menuNum);
			this.price = j.getPrice();
			break;	
		case 3:
			China c = new China();
			c.setMenu(menuNum);			
			this.price = c.getPrice();
			break;
		case 4:
			Spain s = new Spain();
			s.setMenu(menuNum);
			this.price = s.getPrice();
			break;
		case 5:
			France f = new France();
			f.setMenu(menuNum);
			this.price = f.getPrice();
			break;
		case 6:
			Italia i = new Italia();
			i.setMenu(menuNum);
			this.price = i.getPrice();
			break;
		}
	}
}
