package model.Dtos;

import model.Interfaces.Western;

public class Italia extends Cook implements Western{
	private String menu1 = "피자";
	private String menu2 = "라자냐";
	@Override
	public String cooking() {
	    StringBuilder sb = new StringBuilder();
	    sb.append(deepFrying()).append("\n");
	    sb.append(Grilling()).append("\n");
	    sb.append(Sauteing()).append("\n");
	    return sb.toString();
	}
	@Override
	public void setMenu(int num) {
		// TODO Auto-generated method stub
		super.menuNum = num;
		if (this.menuNum == 1) {
			super.price1 = 30;			
		} else {
			super.price2 = 40;			
		}
	}
	
	@Override
	public String cut() {
		return "italian style cut";
	}

	@Override
	public String slice() {
		return "italian style slice";
	}

	@Override
	public String peel() {
		return "italian style peel";
	}

	@Override
	public String deepFrying() {
		return "italian fries";
	}

	@Override
	public String Grilling() {
		return "italian Grilling";
	}

	@Override
	public String Sauteing() {
		return "italian Sauteing";
	}
	@Override
	public String getBread() {
		return Western.bread;
	}
	@Override
	public String toString() {
		return "이탈리아식 1 : " + this.menu1 + ", 2 : " + this.menu2;
	}

	public String getMenu() {
		if (this.menuNum == 1) {
			
			return this.menu1;
		} else {
			
			return this.menu2;
		}
	}

}
