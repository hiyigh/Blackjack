package model.Dtos;

import model.Interfaces.Western;

public class France extends Cook implements Western{
	
	private String menu1 = "코코뱅";
	private String menu2 = "푸아그라";
	@Override
	public String cooking() {
	    StringBuilder sb = new StringBuilder();
	    sb.append(deepFrying()).append("\n");
	    sb.append(Grilling()).append("\n");
	    sb.append(Sauteing()).append("\n");
	    return sb.toString();
	}
	@Override
	public void setMenu(int num) {
		// TODO Auto-generated method stub
		super.menuNum = num;
		if (this.menuNum == 1) {
			super.price1 = 30;			
		} else {
			super.price2 = 40;			
		}
	}
	@Override
	public String cut() {
		return "french style cut";
	}

	@Override
	public String slice() {
		return "french style slice";
	}

	@Override
	public String peel() {
		return "french style peel";
	}


	@Override
	public String deepFrying() {
		return "french fries";
	}

	@Override
	public String Grilling() {
		return "french Grilling";		// TODO Auto-generated method stub
	}

	@Override
	public String Sauteing() {
		return "french Sauteing";
	}
	@Override
	public String getBread() {
		return Western.bread;
	}
	@Override
	public String toString() {
		return "프랑스식 1 : " + this.menu1 + ", 2 : " + this.menu2;
	}

	public String getMenu() {
		if (this.menuNum == 1) {
			
			return this.menu1;
		} else {
			
			return this.menu2;
		}
	}


}
