package model.Dtos;

import model.Interfaces.Asia;

public class Japan extends Cook implements Asia{
	private String menu1 = "덮밥";
	private String menu2 = "초밥";
	@Override
	public String cooking() {
	    StringBuilder sb = new StringBuilder();
	    sb.append(boiling()).append("\n");
	    sb.append(mixing()).append("\n");
	    return sb.toString();
	}
	@Override
	public void setMenu(int num) {
		// TODO Auto-generated method stub
		super.menuNum = num;
		if (this.menuNum == 1) {
			super.price1 = 30;			
		} else {
			super.price2 = 40;			
		}
	}
	
	public String cut() {
		return "다지는 중";		
	}

	@Override
	public String slice() {
		return "얇게써는 중";		
	}

	@Override
	public String peel() {
		return "깍는 중";		
	}


	@Override
	public String boiling() {
		return "japanese style boiling";		
	}

	@Override
	public String mixing() {
		return "japanese style mixing";		
	}
	@Override
	public String getFortuneCookie() {
		return Asia.fortunecookie;
	}	
	@Override
	public String toString() {
		return "일식 1 : " + this.menu1 + ", 2 : " + this.menu2;
	}

	public String getMenu() {
		if (this.menuNum == 1) {
			
			return this.menu1;
		} else {
			
			return this.menu2;
		}
	}

}
