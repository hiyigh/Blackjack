package model.Dtos;

import model.Interfaces.Asia;

public class China extends Cook implements Asia {
	private String menu1 = "동파육";
	private String menu2 = "어육";

	@Override
	public String cooking() {
	    StringBuilder sb = new StringBuilder();
	    sb.append(boiling()).append("\n");
	    sb.append(mixing()).append("\n");
	    return sb.toString();
	}

	@Override
	public void setMenu(int num) {
		// TODO Auto-generated method stub
		super.menuNum = num;
		if (this.menuNum == 1) {
			super.price1 = 30;
		} else {
			super.price2 = 40;
		}
	}

	public String cut() {
		return "크게 자르는 중";
	}

	@Override
	public String slice() {
		return "써는 중";
	}

	@Override
	public String peel() {
		return "뭐 하는 중";
	}

	@Override
	public String boiling() {
		// TODO Auto-generated method stub
		return "chinese style boiling";
	}

	@Override
	public String mixing() {
		// TODO Auto-generated method stub
		return "chinese style mixing";
	}

	@Override
	public String getFortuneCookie() {
		return Asia.fortunecookie;
	}

	@Override
	public String toString() {
		return "중식 1 : " + this.menu1 + ", 2 : " + this.menu2;
	}

	public String getMenu() {
		if (this.menuNum == 1) {

			return this.menu1;
		} else {

			return this.menu2;
		}
	}

}
