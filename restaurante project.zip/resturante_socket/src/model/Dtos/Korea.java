package model.Dtos;

import java.io.Serializable;

import model.Interfaces.Asia;

public class Korea extends Cook implements Asia{
	private String menu1 = "너비아니";
	private String menu2 = "굴비";	
	
	@Override
	public String cooking() {
	    StringBuilder sb = new StringBuilder();
	    sb.append(boiling()).append("\n");
	    sb.append(mixing()).append("\n");
	    return sb.toString();
	}
	@Override
	public void setMenu(int num) {
		// TODO Auto-generated method stub
		super.menuNum = num;
		if (this.menuNum == 1) {
			super.price1 = 30;			
		} else {
			super.price2 = 40;			
		}
	}
	@Override
	public String cut() { 
		return "깍뚝썰기 중";
	}

	@Override
	public String slice() {
		return "저미는 중";
	}

	@Override
	public String peel() {
		return "벗기는 중";
	}

	@Override
	public String boiling() {
		return "삶는 중";
	}

	@Override
	public String mixing() { 
		return "섞는 중";
	}
	@Override
	public String getFortuneCookie() {
		return Asia.fortunecookie;
	}	
	@Override
	public String toString() {
		return "한식 1 : " + this.menu1 + ", 2 : " + this.menu2;
	}
	public String getMenu() {
		if (this.menuNum == 1) {			
			return this.menu1;
		} else {			
			return this.menu2;
		}
	}
}
