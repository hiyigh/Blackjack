package model.Dtos;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.io.Serializable;

public abstract class Cook implements Serializable{
	// 추가된 변수
	public int menuNum;
	public int price1;
	public int price2;
	
	public abstract String cut();
	public abstract String slice();
	public abstract String peel();
	public abstract void setMenu(int num);
	public void ready(BufferedReader br, PrintWriter pw) {
		
		pw.print("재료 준비중");
		pw.flush();
		
		for (int i = 0; i < 10; ++i) {
			pw.print(".");
			pw.flush();
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		pw.println();
		pw.flush();	
		
		pw.println(cut());
		pw.flush();
		
		pw.println(slice());
		pw.flush();
		
		pw.println(peel());
		pw.flush();

	}
	public abstract String cooking();
	protected int getMenuNum() {
		return this.menuNum;
	}
	public int getPrice() {
		if (menuNum == 1) {
			return this.price1;
		} else {
			return this.price2;
		}
	}
}
