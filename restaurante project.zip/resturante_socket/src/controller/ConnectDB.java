package controller;

public class ConnectDB {
	public static Connection callDB() {
		Connection con = null;
	}
}
