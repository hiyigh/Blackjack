package controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import model.Dtos.Order;
import model.Entity.Customer;
import model.Entity.Reservation;
import model.Interfaces.Info;

public class Manager {
	//고객정보 , 예약정보
	//주문전달, 계산
	private static Manager manager = null;
	private static final int totalTableCnt = 20;
	
	private ArrayList<Info> customerInfoList = new ArrayList<>();
	private ArrayList<Info> reservationInfoList = new ArrayList<>();
	private int[] totalPriceList = new int[20];
	
	private Manager() {
		readFileInfo(0);
		readFileInfo(1);
	}
	public static Manager callManager() {
		if (manager == null) {
			return manager = new Manager();
		}
		return manager;
	}
	
	
	public int deleteCustomerInfo(int customerNum, String name) {		
		Customer c = null;
		Customer rc = null;
		int cn = -1;
		for(Info in : this.customerInfoList) {
			 c = (Customer)in;
			 if(c.getCustomerNum() == customerNum && c.getName().equals(name)) {
				 cn = c.getCustomerNum();
				 rc = c;
				 break;
			 }
		}
		if(rc != null) {
			this.customerInfoList.remove(c);
			System.out.println("고객 삭제");	
		}
		writeFileInfo(0);
		return cn;
	}
	public boolean deleteReservationInfo(String name, int phone) {	
		Reservation r = null;
		boolean flag = false;
		for (int i = this.reservationInfoList.size()-1; i >=0; --i) {
			r = (Reservation)this.reservationInfoList.get(i);
			if (r.getCustomerName().equals(name) && r.getPhone() == phone) {
				this.reservationInfoList.remove(i);				
				
				System.out.println("예약 정보 삭제 완료");
				return true;
			}
		}	
		writeFileInfo(1);
		return false;
	}
	public ArrayList<Info> getCustomerInfoList(){
		return this.customerInfoList;
	}
	public ArrayList<Info> getReservationInfoList(){
		return this.reservationInfoList;
	}
	public ArrayList<Order> sendOrder(Customer customer, int customerId) {				
		customer.setCustomerNum(customerId);
				
		ArrayList<Order> orderListForChef = new ArrayList<>(customer.orderList);
		calculating(orderListForChef);
		
		return orderListForChef;
	}
	public void calculating(ArrayList<Order> orderList) {
		for (Order order : orderList) {			
			this.totalPriceList[(int) (order.customerNum % 20)]  += order.getPrice();
		}
	}
	public int paying(int customerNum) {
		return totalPriceList[(int) (customerNum % 20)];
	}
	
	public void readFileInfo(int fileType) {			
		String fileName = null;
		ObjectInputStream ois = null;
		if (!( 0 == fileType || 1 == fileType)) {
			System.out.println("파일 정보: 0 or 1 입력");
			return;
		} else {
			switch(fileType) {
			case 0 : 
				fileName = "customerInfoList.txt";
				break;
			case 1 : 
				fileName = "reservationInfoList.txt";
				break;
			}
		}	
		try {
			ois = new ObjectInputStream(new FileInputStream(new File(fileName)));
			ArrayList<Info> infoList = (ArrayList<Info>) ois.readObject();	
			if(!infoList.isEmpty()) {				
				if (infoList.get(0) instanceof Customer) {
					this.customerInfoList = (ArrayList<Info>) infoList;							
				} else if (infoList.get(0) instanceof Reservation){
					this.reservationInfoList = (ArrayList<Info>) infoList;				
				}
			}
		} catch (ClassNotFoundException e){
			e.printStackTrace();
		} catch(FileNotFoundException e){
			System.out.println("파일이 없습니다.");					    		   
		} catch(IOException e) {
			System.out.println("빈 파일, fileType: " + fileType);	
		} finally {
			try {
				if (ois == null) return;
				ois.close();
			} catch (IOException e) {				
				e.printStackTrace();
			}
		}
		
	}	
	public void addFileInfo(Info info) {
		int fileNum = -1;
		if (info == null) {
			return;
		}
		
		if (info instanceof Customer) {			
			fileNum = 0;

			Customer c = (Customer)info;
			customerInfoList.add(c);	
		} else if (info instanceof Reservation){			
			fileNum = 1;
			
			Reservation r = (Reservation)info;						
			reservationInfoList.add(r);
		}
		writeFileInfo(fileNum);		
	}
	private void writeFileInfo(int fileNum) {
		ObjectOutputStream oos = null;
		String fileName = null;
		if (fileNum == 0) {
			fileName = "customerInfoList.txt";
		} else if (fileNum == 1) {
			fileName = "reservationInfoList.txt";
		} else {
			System.out.println("writeFileInfo fileNum error");
		}
		try {
			oos = new ObjectOutputStream(new FileOutputStream(new File(fileName)));
			if (fileNum == 0) {
	            oos.writeObject(customerInfoList); // customerInfoList 쓰기
	        } else if (fileNum == 1) {
	            oos.writeObject(reservationInfoList); // reservationInfoList 쓰기
	        } else {
	        	System.out.println("addFileInfo set fileNum Exception");
	        }
		} catch(IOException e) {	
		} finally {
			try {
				oos.close();
			} catch (IOException e) {				
				e.printStackTrace();
			}
		}
	}
	public boolean alreadyReserved(Customer customer) {
		Reservation r = null;
		for (int i = this.reservationInfoList.size()-1; i >=0; --i) {
			r = (Reservation)this.reservationInfoList.get(i);
			if (r.getCustomerName().equals(customer.getName()) && r.getPhone() == customer.getPhone()) {				
				return true;
			}
		}
		return false;
	}
	
}
