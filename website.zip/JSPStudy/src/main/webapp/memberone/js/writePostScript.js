function writeSave() {
	if(document.writePost.id.value == ""){
		alert("작성자를 입력하십시요.");
		document.writePost.writer.focus();
		return false;
	}
	if (document.writePost.title.value == "") {
		alert("제목을 입력하십시요.");
		document.writePost.title.focus();
		return false;
	}
	if (document.writePost.content.value == "") {
		alert("내용을 입력하십시요.");
		document.writePost.content.focus();
		return false;
	}
}