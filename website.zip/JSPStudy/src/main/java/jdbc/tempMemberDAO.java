package jdbc;

import java.sql.*;
import java.util.*;
import jdbc.tempMemberVO;

public class tempMemberDAO {
//	private final String JDBC_DRIVER = "oracle.jdbc.driver.OracleDriver"; 
//	private final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
//	private final String USER = "jdbc";
//  private final String PASS = "jdbc";
	private ConnectionPool pool = null;

	public Vector<tempMemberVO> getMemberList() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		Vector<tempMemberVO> vecList = new Vector<tempMemberVO>();

		try {
//			conn = DriverManager.getConnection(JDBC_URL,USER,PASS);
			conn = pool.getConnection();
			String sql = "select * from tempMember";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				tempMemberVO vo = new tempMemberVO();
				vo.setId(rs.getString("id"));
				vo.setPasswd(rs.getString("passwd"));
				vo.setName(rs.getString("name"));
				vo.setMem_num1(rs.getString("mem_num1"));
				vo.setMem_num2(rs.getString("mem_num2"));
				vo.setEmail(rs.getString("e_mail"));
				vo.setPhone(rs.getString("phone"));
				vo.setZipcode(rs.getString("zipcode"));
				vo.setAddress(rs.getString("address"));
				vo.setJob(rs.getString("job"));
				vecList.add(vo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			pool.disconnectResources(rs, stmt, conn);
		}
		return vecList;
	}
}
