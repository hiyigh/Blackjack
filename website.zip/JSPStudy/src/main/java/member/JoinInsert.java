package member;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import bbs.ConnectDB;

/**
 * Servlet implementation class JoinInsert
 */
public class JoinInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void processRequest(HttpServletRequest req, HttpServletResponse res) {
		Connection con = ConnectDB.callDB();
		PreparedStatement pstmt = null;
		try {
			req.setCharacterEncoding("utf-8");
			
			String id = req.getParameter("id");		
			String password = req.getParameter("pw");			
			String name = req.getParameter("name");
			String email = req.getParameter("email");
			String email2 = req.getParameter("domain-txt");
			String fullEmail = email + "@" + email2;
			
			String address1 = req.getParameter("zip_code");
			String address2 = req.getParameter("address");			
			String address3 = req.getParameter("detail_address");

			String sql = "insert into member values(member_seq.nextval, ?,?,?, ?,?,?,?)";
			
			pstmt = con.prepareStatement(sql);			

			pstmt.setString(1, id);
			pstmt.setString(2, password);
			pstmt.setString(3, name);
			pstmt.setString(4, fullEmail);
			pstmt.setString(5, address1);
			pstmt.setString(6, address2);
			pstmt.setString(7, address3);
			
			pstmt.executeUpdate();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			//
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		try {
			res.sendRedirect("/JSPStudy/bbs/member/login.html");
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}
}
