package member;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.websocket.Session;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import bbs.ConnectDB;

/**
 * Servlet implementation class LoginInsert
 */
public class LoginInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginInsert() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void processRequest(HttpServletRequest req, HttpServletResponse res) {
		Connection con = ConnectDB.callDB();
		CallableStatement cstmt = null;
		int result = 0;
		try {
			req.setCharacterEncoding("utf-8");
			String id = req.getParameter("id");						
			String password = req.getParameter("password");
			String sql = "{? = call login_func(?,?)}";
									
			cstmt = con.prepareCall(sql);
			cstmt.registerOutParameter(1, Types.INTEGER);
			cstmt.setString(2, id);
			cstmt.setString(3, password);
			cstmt.execute();
			
			result = cstmt.getInt(1);			
			if (result == 1) {
				HttpSession session = req.getSession();
				session.setAttribute("user", id);
				try {
					res.sendRedirect("/JSPStudy/VisitList");
				} catch (IOException e) {
					e.printStackTrace();
				}
				return;
			}
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				cstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		try {
			System.out.println("없는 로그인 정보");
			res.sendRedirect("/JSPStudy/bbs/member/login.html");
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request,response);
	}

}
