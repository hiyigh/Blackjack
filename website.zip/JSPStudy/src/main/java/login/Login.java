package login;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;


public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void processRequest(HttpServletRequest req, HttpServletResponse res) {
		res.setContentType("text/html;charset=utf-8");
		PrintWriter pw = null;
		try {
			pw = res.getWriter();
			HttpSession session = req.getSession(false);
			if (session != null) {
				String sessionId = session.getId();
				String user = (String) session.getAttribute("user");
				
				pw.println("<html>");
				pw.println("<body>");
				pw.println("<table border='1' width='300'>");
				pw.println("<tr>");
				pw.println("<td width='300' align='center'>" + user + " 로그인 " + "</td>");
				pw.println("</tr>");
				pw.println("<td align='center'>");
				pw.println("<a href='#'>회원정보</a> <a href='#'>로그아웃</a>");
				pw.println("</td>");
				pw.println("</tr>");
				pw.println("</table>");
				pw.println("</body>");
				pw.println("</html>");
			} else {
				pw.println("<html>");
				pw.println("<script>");
				pw.println("function join() {"
						+ "window.location.href = '/JSPStudy/bbs/member/join.html';"
						+ "}");				
				pw.println("</script>");
				pw.println("<body>");
				pw.println("<form method='post' action='LoginInsert'>");
				pw.println("<table border='1' width='300'>");
				pw.println("<tr>");
				pw.println("<th width='100'>아이디</th>");
				pw.println("<td width='200' align='center'><input type='text' name='id' placeholder='ID'></td>");
				pw.println("</tr>");
				pw.println("<tr>");
				pw.println("<th width='100'>비밀번호</th>");
				pw.println("<td width='200' align='center'>"
							+ "<input type='password' name='password' placeholder='PASSWORD'>"
						+ "</td>");
				pw.println("</tr>");
				pw.println("<tr>");
				pw.println("<td colspan='2' align='center'>"
							+ "<input type='button' onclick='join()' value='회원가입'>"
							+ "<input type='submit' value='로그인'>"
						+ "</td>");
				pw.println("</tr>");
				pw.println("</table>");
				pw.println("</form>");		
				pw.println("</body>");
				pw.println("</html>");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			pw.close();
		}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
}
