package sample;

import jakarta.servlet.ServletException;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.FileInputStream;
import java.io.IOException;

/**
 * Servlet implementation class FileDownloadTest
 */
public class FileDownloadTest extends HttpServlet {
	private static final long serialVersionUID = 1L;
         
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fileName = request.getParameter("fileName");
		String downloadPath = "C:/temp2/";
		String filepath = downloadPath + fileName;
		
		String encodingFileName = new String(fileName.getBytes("utf-8"));
		ServletOutputStream stream = null;
		// 파일을 읽어서 클라이언트 브라우저에 출력
		byte[] b = new byte[4096];
		
		try {
			FileInputStream fileInputStream = new FileInputStream(filepath);
			
			//file MIME type
			// 파일 경로에서 get mime type?
			String sMimeType = getServletContext().getMimeType(filepath);
			if (sMimeType == null) {
				sMimeType = "application/octet-stream";
			}
			response.setContentType(sMimeType);
			response.setHeader("Content-Disposition", "attachment; filename=" + encodingFileName);
			
			stream = response.getOutputStream();
			int read;
			while((read = fileInputStream.read(b, 0, b.length)) != -1) {
				stream.write(b,0,read);
			}
		} catch(IOException e) {
			e.printStackTrace();
		} finally {
			stream.flush();
		}
	}
	// content type , header , write
}
