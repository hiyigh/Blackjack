package sample;

public class SimpleData {
	private String message;
	public void setMessage(String msg) {
		this.message = msg;
	}
	public String getMessage() {
		return this.message;
	}
}
