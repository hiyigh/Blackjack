package sample;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class Destination
 */
public class Destination extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) {
    	
    	response.setContentType("text/html;charset=utf-8");
    	PrintWriter pw = null;
    	try {
			pw = response.getWriter();
			pw.println("<html>");
			pw.println("<head>");
			pw.println("<title>Destination</title>");
			pw.println("</head>");
			pw.println("<body>");
			pw.println("<h1>Destination Servlet</h1>");
			pw.println("</body>");
			pw.println("</html>");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			pw.close();
		}
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);

	}

}
