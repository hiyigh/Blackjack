package memberone;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;

public class PostDAO {
	
	private static ConnectionPool pool = ConnectionPool.getInstance();
	private static PostDAO instance = null;
	
	public static PostDAO getInstance() {
		if (instance == null) {
			synchronized(PostDAO.class) {
				instance = new PostDAO();
			}
		}
		return instance;
	}	
	
	public PostVO getSelectPost(int no) {
		Connection con = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
		String sql = "{call getSelect_proc(?,?)}";
		PostVO pvo = null;
		try {
			con = pool.getConnection();
			cstmt = con.prepareCall(sql);
			cstmt.setInt(1, no);
			cstmt.registerOutParameter(2, Types.REF_CURSOR);
			cstmt.execute();
			
			rs = (ResultSet)cstmt.getObject(2);
			while(rs.next()) {
				pvo = new PostVO();
				pvo.setNo(rs.getInt("p_no"));
				pvo.setDate(rs.getString("p_date"));
				pvo.setTitle(rs.getString("p_title"));
				pvo.setContent(rs.getString("p_content"));
				pvo.setId(rs.getString("p_id"));
				pvo.setView(rs.getInt("p_view"));
				pvo.setParentNo(rs.getInt("parentNo"));
				pvo.setLevel(rs.getInt("p_level"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				cstmt.close();
				pool.releaseConnection(con);

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (pvo == null) {
			System.out.println("get select pvo is null");
			return null;
		}
		return pvo;
	}
	
	public ArrayList<PostVO> getAllPostList() {
		Connection con = null;
		CallableStatement cstmt = null;
//		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "{call getAllPost_proc(?)}";
//		String sql = "select * from post";
		ArrayList<PostVO> pList = new ArrayList<PostVO>();
		try {
			con = pool.getConnection();
			cstmt = con.prepareCall(sql);
			cstmt.registerOutParameter(1, Types.REF_CURSOR);
//			pstmt = con.prepareStatement(sql);
//			rs = (ResultSet) pstmt.executeQuery();
			cstmt.executeQuery();
			rs = (ResultSet)cstmt.getObject(1);
			if (rs != null) {				
				while(rs.next()) {
					PostVO pvo = new PostVO();
					pvo.setNo(rs.getInt("p_no"));
					pvo.setDate(rs.getString("p_date"));
					pvo.setTitle(rs.getString("p_title"));
					pvo.setId(rs.getString("p_id"));
					pvo.setView(rs.getInt("p_view"));
					pvo.setParentNo(rs.getInt("parentNo"));
					pvo.setLevel(rs.getInt("p_level"));
					pvo.setContent(rs.getString("p_content"));
					
					pList.add(pvo); 
				}
			} 
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				cstmt.close();
//				pstmt.close();
				pool.releaseConnection(con);

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return pList;
	}
	public boolean savePost(PostVO pvo) {
		Connection con = null;
		CallableStatement cstmt = null;
		int result = 0;
		String sql = "{call savePost_proc(?,?,?, ?,?,?)}";		
		try {
			con = pool.getConnection();
			cstmt = con.prepareCall(sql);
			cstmt.registerOutParameter(1, Types.INTEGER);
			cstmt.setString(2, pvo.getId());
			cstmt.setString(3, pvo.getTitle());
			cstmt.setString(4, pvo.getContent());			
			cstmt.setInt(5, pvo.getParentNo());
			cstmt.setInt(6, pvo.getLevel());
			cstmt.execute();
			
			result = cstmt.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				cstmt.close();
//				pstmt.close();
				pool.releaseConnection(con);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result == 0 ? false : true;
	}
	public boolean deletePost(int postNo) {
		Connection con = null;
		CallableStatement cstmt = null;
		String sql = "{call deletePost_proc(?,?)}";
		boolean result = false;
		try {
			con = pool.getConnection();
			cstmt = con.prepareCall(sql);
			cstmt.registerOutParameter(1, Types.BOOLEAN);
			cstmt.setInt(2, postNo);
			cstmt.executeUpdate();
			result = cstmt.getBoolean(1);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				cstmt.close();
//				pstmt.close();
				pool.releaseConnection(con);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return result;
	}
	public boolean updatePost(PostVO pvo) {
		//날짜 제목 내용
		Connection con = null;
		CallableStatement cstmt = null;
		String sql = "{call updatePost_proc(?,?,?,?)}";
		boolean result = false;
		try {
			con = pool.getConnection();
			cstmt = con.prepareCall(sql);
			cstmt.registerOutParameter(1, Types.BOOLEAN);
			cstmt.setInt(2, pvo.getNo());
			cstmt.setString(3, pvo.getTitle());
			cstmt.setString(4, pvo.getContent());
			cstmt.executeUpdate();
			result = cstmt.getBoolean(1);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				cstmt.close();
//				pstmt.close();
				pool.releaseConnection(con);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}
	public boolean checkWriter(int loginNo, String Id) {
		Connection con = null;
		CallableStatement cstmt = null;
		boolean result = false;
		String sql ="{? = call checkWriter_func(?,?)}";
		try {
			con = pool.getConnection();
			cstmt = con.prepareCall(sql);
			cstmt.registerOutParameter(1, Types.BOOLEAN);
			cstmt.setInt(2, loginNo);
			cstmt.setString(3, Id);
			cstmt.execute();
			result = cstmt.getBoolean(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}	
}
