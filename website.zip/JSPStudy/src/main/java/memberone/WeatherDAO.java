package memberone;

public class WeatherDAO {

}
