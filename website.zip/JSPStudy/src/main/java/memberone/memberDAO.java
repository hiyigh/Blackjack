package memberone;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Vector;

public class memberDAO {
	private static ConnectionPool pool = ConnectionPool.getInstance();
	private static memberDAO instance = null;
	
	public static memberDAO getInstance() {
		if (instance == null) {
			synchronized(memberDAO.class) {
				instance = new memberDAO();
			}
		}
		return instance;
	}
	private memberDAO() {};

	public boolean idCheck(String id) {		
		Connection con = null;
		CallableStatement cstmt = null;	
		int result = 0;
		String sql = "{? = call idcheck_func(?)}";
		try {
			con = pool.getConnection();
			cstmt = con.prepareCall(sql);
			cstmt.registerOutParameter(1, Types.INTEGER);
			cstmt.setString(2, id);
			cstmt.execute();
			
			result = cstmt.getInt(1);
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			try {
				cstmt.close();
				pool.releaseConnection(con);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (result == 0) {
			return false;
		}
		return true;
	}

	public boolean memberInsert(memberVO vo) {
		Connection con = null;
		PreparedStatement pstmt = null;
		int cnt = 0;
		try {
			con = pool.getConnection();
			String sql = "insert into member values(member_seq.nextval,?,?,?,?, ?,?,?,?)";
		
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getPassword());
			pstmt.setString(3, vo.getName());
			pstmt.setString(4, vo.getEmail() + "@" + vo.getDomain_txt());
			pstmt.setString(5, vo.getZip_code());
			
			System.out.println("member insert: " + vo.getAddress());
			
			pstmt.setString(6, vo.getAddress());
			pstmt.setString(7, vo.getDetail_address());
			pstmt.setInt(8, vo.getPhone());
			
			cnt = pstmt.executeUpdate();				
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		return (cnt == 0) ? false:true;
	}
	
	public int loginCheck(String id , String password) {
		Connection con = null;
		CallableStatement cstmt = null;
		int check = -1;
		try {
			con = pool.getConnection();
			String sql = "{? = call loginCheck_func(?,?)}";
			System.out.println("logincheck : " + id + "   " + password);
			cstmt = con.prepareCall(sql);
			cstmt.registerOutParameter(1, Types.NUMERIC);
			cstmt.setString(2, id);
			cstmt.setString(3, password);
			cstmt.execute();
			
			check = cstmt.getInt(1);			
			System.out.println("login check result : " + check);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				cstmt.close();
				pool.releaseConnection(con);

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return check;
	}
	
	public memberVO getMemberVO(int no) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		memberVO mvo = null;
		String sql = "select * from member where no = ?";
		
		try {
			con = pool.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1,no);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				mvo = new memberVO();
				mvo.setId(rs.getString("id"));
				mvo.setPassword(rs.getString("password"));
				mvo.setName(rs.getString("name"));
				String[] split = rs.getString("email").split("@");
				
				mvo.setEmail(split[0]);
				mvo.setDomain_txt(split[1]);
				mvo.setZip_code(rs.getString("zip_code"));
				
				System.out.println("getMembervo address: " + rs.getString("address") + rs.getString("detail_address"));
				
				mvo.setAddress(rs.getString("address"));
				mvo.setDetail_address(rs.getString("detail_address"));	
				mvo.setPhone(rs.getInt("phone"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
				pool.releaseConnection(con);

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return mvo;
	}
	public void updateMemberVO(int no, memberVO vo) {
		Connection con = null;
		CallableStatement cstmt = null;
		String sql = "{call updateMember_proc(?, ?,?, ?,?, ?,?,?,?)}";
		try {
			con = pool.getConnection();
			cstmt = con.prepareCall(sql);
			cstmt.setInt(1, no);
			cstmt.setString(2,vo.getId());
			cstmt.setString(3,vo.getPassword());
			cstmt.setString(4,vo.getName());
			cstmt.setString(5,vo.getEmail() + "@" + vo.getDomain_txt());
			cstmt.setString(6,vo.getZip_code());
			
			System.out.println("update member address: " + vo.getAddress());

			cstmt.setString(7,vo.getAddress());
			cstmt.setString(8,vo.getDetail_address());
			cstmt.setInt(9,vo.getPhone());
			
			cstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {				
				cstmt.close();
				pool.releaseConnection(con);

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	public boolean deleteMember(int no, String pwd) {
		Connection con = null;
		PreparedStatement pstmt = null;		
		int result = 0;
		
		String sql = "delete from member where no = ? and password like ?";
		try {
			con = pool.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);
			pstmt.setString(2, pwd);
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return (result == 0)?false:true;
	}
	public ArrayList<memberVO> getAllMemberData() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<memberVO> mList = new ArrayList<memberVO>();
		String sql = "select * from member";
		try {
			con = pool.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs != null) {
				while(rs.next()) {
					memberVO m = new memberVO();
					m.setId(rs.getString("id"));
					m.setName(rs.getString("name"));
					m.setEmail(rs.getString("email"));
					m.setZip_code(rs.getString("zip_code"));
					m.setAddress(rs.getString("address"));
					m.setDetail_address(rs.getString("detail_address"));
					m.setPhone(rs.getInt("phone"));
					mList.add(m);
				}		
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return mList;
	}
	public int kickoutMember(String[] memberList) {
		Connection con = null;
		PreparedStatement pstmt = null;
		int result = 0;
		
		String sql = "delete from member where id = ?";
		try {
			con = pool.getConnection();
			
			for (int i = 0; i < memberList.length; ++i) {
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, memberList[i]);
				result = pstmt.executeUpdate();
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
}
	