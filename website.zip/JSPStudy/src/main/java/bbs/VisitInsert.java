package bbs;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class VisitInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void processRequest(HttpServletRequest req, HttpServletResponse res)  {
		Connection con = ConnectDB.callDB();
		PreparedStatement pstmt = null;
		try {
			req.setCharacterEncoding("utf-8");
			String writer = req.getParameter("writer");
			String memo = req.getParameter("memo");
			
			System.out.println("writer: " + writer);
			System.out.println("memo: " + memo);
			
			// string buffer?
			StringBuffer sql = new StringBuffer();
			sql.append("insert into visit values (vis_seq.nextval, ?, ?, sysdate)");
			try {
				pstmt = con.prepareStatement(sql.toString());
				pstmt.setString(1, writer);
				pstmt.setString(2, memo);
				pstmt.executeQuery();
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		try {
			res.sendRedirect("VisitList");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(req, resp);
	}
}
