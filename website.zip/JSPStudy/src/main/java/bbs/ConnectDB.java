package bbs;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectDB {
	public static Connection callDB() {
		String filepath = "D:/WebEclipseProject/myproject/jsp/JSPStudy/src/main/java/db.properties";
		Properties properties = new Properties();

		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			properties.load(new FileReader(filepath));
			String url = properties.getProperty("url");
			String id = properties.getProperty("id");
			String pwd = properties.getProperty("pwd");

			con = DriverManager.getConnection(url, id, pwd);
			
			if (con != null) System.out.println("접속");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
}
