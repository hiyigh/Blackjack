package bbs;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Servlet implementation class VisitList
 */
public class VisitList extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public VisitList() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void processRequest(HttpServletRequest req, HttpServletResponse res) {
		Connection con = ConnectDB.callDB();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		PrintWriter pw = null;
		ArrayList<Visit> visitList = new ArrayList<Visit>();
		res.setContentType("text/html;charset=utf-8");
		try {
			pw = res.getWriter();
			pw.println("<html>");
			pw.println("<head><title>방명록 리스트</title></head>");
			
			pw.println("<body>");
			pw.println("<nav>");
			pw.println("<a href='/JSPStudy/Logout'>로그아웃</a>");
			pw.println("</nav>");
			String sql = "select no,writer, memo, regdate from visit order by no desc";

			try {
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();

				while (rs.next()) {
					Visit v = new Visit();
					
					int no = rs.getInt("no");
					String writer = rs.getString("writer");
					String memo = rs.getString("memo");
					Date regdate = rs.getDate("regdate");
					v.setNo(no);
					v.setWriter(writer);
					v.setMemo(memo);
					v.setRegDate(regdate.toString());					
					
					pw.println("<form method='post' action='/JSPStudy/VisitDelete'>");
					pw.println("<table align=center width=500 border=1>");
					pw.println("<tr>");
					pw.println("<th width=50>번호</th>");
					String value = String.format("<td width=50 align=center><input name='checkbox' class='boxs' type='checkbox' value='%s'>" + no + "</td>", no);				
					pw.println(value);
					pw.println("<th width=70>작성자</th>");
					pw.println("<td width=180 align=center>" + writer + "</td>");
					pw.println("<th width=50>날짜</th>");
					pw.println("<td width=100 align=center>" + regdate + "</td>");
					pw.println("</tr>");
					pw.println("<tr>");
					pw.println("<th width=50>내용</th>");
					pw.println("<td colspan=5>&nbsp; " + "<textarea rows=3 cols=50>" + memo + "</textarea></td>");
					pw.println("</tr>");
					pw.println("</table>");
					pw.println("<p>");

				}
				pw.println("<p align=center>" + "<a href=/JSPStudy/bbs/write.html>글쓰기</a>" + "</p>");
				pw.println("<p align=center>" + "<button type='submit'>삭제</button>" + "</p>");
				pw.println("</form>");				
				pw.println("</body>");
				pw.println("</html>");
			} catch (SQLException e) {

				e.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
				con.close();
				pw.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

}
