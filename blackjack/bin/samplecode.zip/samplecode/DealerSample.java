package samplecode;

import java.util.ArrayList;

import blackjack.Card;
import blackjack.Player;

public class Dealer {
	private static int[][] deck;
	private static ArrayList<Card> dealerCardList;
	private static ArrayList<Player> winnerList = new ArrayList<>();
	private static int playerScore = -1;
	private static int playerNum = -1;
	
	private static int dealerScore;
	private static final int seventeen = 17;
	private static int highscore = 0;
	
	private static Dealer dealer = null;
	
	private Dealer(){

	}
	public static Dealer getDealer() {

	}
	public Card deal(int turn, int playerChoice) {

	}
	private Card shuffle() {

	}
	private String hit() {

	}
	private void calculateDealerScore() {

	}
	private int selectWinner(ArrayList<Player> playerList) {
		
	}
}
